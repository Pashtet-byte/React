import { mockFetchUser } from "./api.js";
import { isPasswordSecure, isAgeValid } from "./mathUtils.js";
import { fetchDataWithCancel } from "./cancellableFetch.js";

console.log("--- Этап 2: валидаторы ---");
console.log(isPasswordSecure("12345"));
console.log(isPasswordSecure("superSecret1"));
console.log(isAgeValid(17), isAgeValid(30));

// СЦЕНАРИЙ 1: Отказоустойчивая загрузка виджетов дашборда через Promise.allSettled
async function loadDashboardWidgets() {
  const userIds = ["u1", "u2_failed", "u3"];

  const requests = userIds.map((id) =>
    mockFetchUser(id, { shouldFail: id.includes("failed") })
  );

  const results = await Promise.allSettled(requests);

  const successfulUsers = [];
  const failedErrors = [];
  results.forEach((result, index) => {
    if (result.status === "fulfilled") {
      successfulUsers.push(result.value);
    } else {
      failedErrors.push({ id: userIds[index], reason: result.reason.message });
    }
  });
  console.log("Успешно загружены:", successfulUsers);
  console.log("Ошибки загрузки виджетов:", failedErrors);
}

// СЦЕНАРИЙ 2: Fail-Fast через Promise.all (падает при первой ошибке)
async function loadCriticalData() {
  try {
    const users = await Promise.all(
      ["u1", "u2_failed", "u3"].map((id) =>
        mockFetchUser(id, { shouldFail: id.includes("failed") })
      )
    );
    console.log("Все загружены:", users);
  } catch (err) {
    console.log("Promise.all отклонён целиком:", err.message);
  }
}

// СЦЕНАРИЙ 3: отмена запроса через AbortController
async function cancelDemo() {
  const controller = new AbortController();
  setTimeout(() => controller.abort(), 300);
  try {
    await fetchDataWithCancel("/api/report", { signal: controller.signal });
  } catch (err) {
    console.log(`Отмена: ${err.name} — ${err.message}`);
  }
}

console.log("--- Этап 4 ---");
await loadDashboardWidgets();
await loadCriticalData();
console.log("--- Этап 5 ---");
await cancelDemo();
