import assert from "node:assert/strict";

// 1. ESM Module Loader
const math = await import("./mathUtils.js");
const api = await import("./api.js");
assert.equal(typeof math.validateRange, "function");
assert.equal(typeof math.default.curry, "function");
assert.equal(typeof api.delay, "function");
assert.equal(api.default, api.mockFetchUser);
assert.equal(math.add(1)(2)(3), 6);
assert.deepEqual(math.isAgeValid(30), { valid: true });
assert.equal(math.isPasswordSecure("123").valid, false);
console.log("✓ ESM Module Loader: OK (Native Named & Default Exports)");

// 2. Promise.allSettled
const res = await Promise.allSettled(
  ["u1", "u2_failed", "u3"].map((id) =>
    api.mockFetchUser(id, { shouldFail: id.includes("failed"), delayMs: 20 })
  )
);
assert.deepEqual(res.map((r) => r.status), ["fulfilled", "rejected", "fulfilled"]);
assert.equal(res[0].value.role, "admin");
await assert.rejects(
  Promise.all([api.mockFetchUser("x_failed", { shouldFail: true, delayMs: 5 }), api.mockFetchUser("u1", { delayMs: 5 })])
);
console.log("✓ Promise Parallel Pipeline: OK (Promise.allSettled Matrix)");

// 3. AbortController
const { fetchDataWithCancel } = await import("./cancellableFetch.js");
const c = new AbortController();
setTimeout(() => c.abort(), 30);
const t0 = Date.now();
await assert.rejects(fetchDataWithCancel("/x", { signal: c.signal }), { name: "AbortError" });
assert.ok(Date.now() - t0 < 500);
const pre = new AbortController(); pre.abort();
await assert.rejects(fetchDataWithCancel("/x", { signal: pre.signal }), { name: "AbortError" });
console.log("✓ AbortController Signal Dispatch: OK (Clean Abort on User Action)");
