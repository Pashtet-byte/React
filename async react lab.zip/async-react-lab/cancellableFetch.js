import { delay } from "./api.js";

// Асинхронная операция с поддержкой отмены по AbortSignal:
export async function fetchDataWithCancel(url, { signal } = {}) {
  // Проверяем, не был ли сигнал уже отменен до старта:
  if (signal?.aborted) {
    throw new DOMException("Операция отменена до старта", "AbortError");
  }

  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve({ data: `Ответ для ${url}`, timestamp: Date.now() });
    }, 1500);

    // Подписываемся на событие отмены:
    function onAbort() {
      clearTimeout(timer);
      reject(new DOMException("Запрос отменен пользователем", "AbortError"));
    }
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

// Вариант с таймаутом (AbortSignal.timeout):
export const fetchWithTimeout = (url, ms) =>
  fetchDataWithCancel(url, { signal: AbortSignal.timeout(ms) });

export { delay };
