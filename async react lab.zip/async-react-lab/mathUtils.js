// ===== Этап 2: каррирование и модули =====

// 1. Универсальная функция каррирования:
export const curry = (fn) =>
  function curried(...args) {
    return args.length >= fn.length
      ? fn(...args)
      : (...next) => curried(...args, ...next);
  };

// Пример: каррированное сложение
export const add = curry((a, b, c) => a + b + c);

// 2. Каррированная фабрика проверки минимальной длины:
export const validateMinLength = (minLength) => (value) =>
  typeof value === "string" && value.length >= minLength
    ? { valid: true }
    : { valid: false, error: `Длина должна быть не меньше ${minLength} символов` };

// 3. Каррированная фабрика проверки диапазона чисел:
export const validateRange = (min, max) => (value) => {
  return value >= min && value <= max
    ? { valid: true }
    : { valid: false, error: `Число должно быть в диапазоне от ${min} до ${max}` };
};

// Создаем специализированные валидаторы:
export const isPasswordSecure = validateMinLength(8);
export const isAgeValid = validateRange(18, 65);

export default { curry, add, validateMinLength, validateRange, isPasswordSecure, isAgeValid };
